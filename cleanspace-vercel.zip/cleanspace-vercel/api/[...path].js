const crypto = require('crypto');

const initial = () => ({
  services: [
    { id: 1, name: 'Поддерживающая уборка', price: 120, unit: 'м²', description: 'Свежесть и порядок на каждый день' },
    { id: 2, name: 'Генеральная уборка', price: 220, unit: 'м²', description: 'Глубокая очистка каждого уголка' },
    { id: 3, name: 'Уборка после ремонта', price: 290, unit: 'м²', description: 'Удалим строительную пыль и следы ремонта' },
    { id: 4, name: 'Мытьё окон', price: 35, unit: 'окно', description: 'Прозрачные стёкла без разводов' }
  ],
  requests: [],
  reviews: [
    { id: 1, name: 'Анна', rating: 5, text: 'Очень аккуратно и внимательно. Дом буквально засиял!', approved: true, createdAt: new Date().toISOString() },
    { id: 2, name: 'Михаил', rating: 5, text: 'Удобный заказ, приехали вовремя, результат отличный.', approved: true, createdAt: new Date().toISOString() }
  ]
});
// Demo storage: persists only while a serverless instance remains warm.
const state = globalThis.__cleanspaceState || (globalThis.__cleanspaceState = { db: initial(), sessions: new Map() });
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'clean2026';
const SECRET = process.env.SESSION_SECRET || 'change-this-demo-secret-before-production';
const json = (res, status, data, headers = {}) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers }); res.end(JSON.stringify(data)); };
function readBody(req) {
  if (req.body && typeof req.body === 'object') return Promise.resolve(req.body);
  return new Promise((resolve, reject) => {
    let raw = ''; req.on('data', c => { raw += c; if (raw.length > 1e6) reject(new Error('Payload too large')); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}
function tokenFrom(req) { return (req.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith('cs_session='))?.slice(11); }
function signedToken() { const id = crypto.randomBytes(24).toString('hex'); const sig = crypto.createHmac('sha256', SECRET).update(id).digest('hex'); state.sessions.set(id, Date.now() + 8 * 60 * 60 * 1000); return `${id}.${sig}`; }
function authorized(req) {
  const t = tokenFrom(req); if (!t) return false;
  const [id, sig] = t.split('.'); if (!id || !sig) return false;
  const expected = crypto.createHmac('sha256', SECRET).update(id).digest('hex');
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
  const expiry = state.sessions.get(id); if (!expiry || expiry < Date.now()) return false;
  return true;
}
module.exports = async (req, res) => {
  const path = new URL(req.url, 'https://vercel.local').pathname.replace(/\/$/, '') || '/';
  const db = state.db;
  try {
    if (req.method === 'GET' && path === '/api/public') return json(res, 200, { services: db.services, reviews: db.reviews.filter(r => r.approved) });
    if (req.method === 'POST' && path === '/api/requests') {
      const b = await readBody(req);
      if (!b.name || !b.phone || !b.service || !Number.isFinite(Number(b.total)) || Number(b.total) <= 0) return json(res, 400, { error: 'Заполните имя, телефон и параметры заказа.' });
      const item = { id: Date.now(), name: String(b.name).slice(0,100), phone: String(b.phone).slice(0,40), email: String(b.email||'').slice(0,120), service: String(b.service).slice(0,100), area: Number(b.area)||0, extras: Array.isArray(b.extras)?b.extras:[], total: Number(b.total), address: String(b.address||'').slice(0,250), comment: String(b.comment||'').slice(0,1000), status: 'Новая', createdAt: new Date().toISOString() };
      db.requests.unshift(item); return json(res, 201, { ok: true, id: item.id });
    }
    if (req.method === 'POST' && path === '/api/reviews') {
      const b = await readBody(req); if (!b.name || !b.text || !Number(b.rating)) return json(res, 400, { error: 'Укажите имя, оценку и отзыв.' });
      const item = { id: Date.now(), name: String(b.name).slice(0,80), rating: Math.min(5,Math.max(1,Number(b.rating))), text: String(b.text).slice(0,1000), approved: false, createdAt: new Date().toISOString() };
      db.reviews.unshift(item); return json(res, 201, { ok: true, message: 'Спасибо! Отзыв появится после проверки.' });
    }
    if (req.method === 'POST' && path === '/api/login') {
      const b = await readBody(req); if (b.username !== ADMIN_USER || b.password !== ADMIN_PASSWORD) return json(res, 401, { error: 'Неверный логин или пароль.' });
      const token = signedToken(); const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
      return json(res, 200, { ok: true }, { 'Set-Cookie': `cs_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800${secure}` });
    }
    if (req.method === 'POST' && path === '/api/logout') {
      const t = tokenFrom(req); if (t) state.sessions.delete(t.split('.')[0]);
      return json(res, 200, { ok: true }, { 'Set-Cookie': 'cs_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0' });
    }
    if (path.startsWith('/api/admin')) {
      if (!authorized(req)) return json(res, 401, { error: 'Требуется авторизация.' });
      if (path === '/api/admin/data' && req.method === 'GET') return json(res, 200, db);
      const match = path.match(/^\/api\/admin\/(requests|reviews|services)\/(\d+)$/);
      if (match && req.method === 'PATCH') {
        const [, kind, id] = match; const b = await readBody(req); const item = db[kind].find(x => x.id === Number(id));
        if (!item) return json(res, 404, { error: 'Не найдено' }); Object.assign(item, b); return json(res, 200, { ok: true });
      }
      if (match && req.method === 'DELETE') {
        const [, kind, id] = match; db[kind] = db[kind].filter(x => x.id !== Number(id)); return json(res, 200, { ok: true });
      }
      if (path === '/api/admin/services' && req.method === 'POST') {
        const b = await readBody(req); const item = { id: Date.now(), name: String(b.name||'Новая услуга'), price: Number(b.price)||0, unit: String(b.unit||'м²'), description: String(b.description||'') }; db.services.push(item); return json(res, 201, item);
      }
    }
    return json(res, 404, { error: 'Не найдено' });
  } catch (e) { return json(res, 500, { error: e.message || 'Server error' }); }
};
